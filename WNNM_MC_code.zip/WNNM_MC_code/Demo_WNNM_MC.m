% Demo for ALM_WNNM_MC
clc
clear
addpath PROPACK;
pr=0.2;     
ps=0.2;
m=400;
r=round(pr*m);              %Rank of the groundtruth matrix
EL0=round(m*m*ps);          %Number of missing values

U=normrnd(0,1,m,r);V=normrnd(0,1,m,r);
A0=U*V';
support=ones(m,m);
Ind = randperm(m*m);
support(Ind(1:EL0))=0;
D=support.*A0;

fprintf('WNNM_PRCA \n\n')
starttime = tic;
[A_WNNM E_WNNM ]=inexact_alm_WNNM_MC(D,support, sqrt(m*m),eps,1e-7,1000);

time_WNNM=toc(starttime);
RelativeError_WNNM=(sum(sum((A_WNNM-A0).^2))).^0.5/(sum(sum(A0.^2))).^0.5;
rank_WNNM=rank(A_WNNM);

fprintf( 'Relative Error: %e \nRank of estimated matrix: %f \nRunning Time: %f \n', RelativeError_WNNM, rank_WNNM, time_WNNM );


